Elwyn Cruz,104977892,ElwynCruz@g.ucla.edu
Khoi Nguyen,804993073,knguyen99@g.ucla.edu

Sources:
piazza
stackoverflow
TAs
docs.scipy.org
scikit-learn.org